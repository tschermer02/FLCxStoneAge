/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define Emergency_Stop_Pin GPIO_PIN_13
#define Emergency_Stop_GPIO_Port GPIOC
#define Emergency_Stop_EXTI_IRQn EXTI15_10_IRQn
#define X_RotaryEncoder_A_Pin GPIO_PIN_0
#define X_RotaryEncoder_A_GPIO_Port GPIOC
#define X_RotaryEncoder_A_EXTI_IRQn EXTI0_IRQn
#define X_RotaryEncoder_B_Pin GPIO_PIN_1
#define X_RotaryEncoder_B_GPIO_Port GPIOC
#define X_RotaryEncoder_B_EXTI_IRQn EXTI1_IRQn
#define Z_RotaryEncoder_A_Pin GPIO_PIN_3
#define Z_RotaryEncoder_A_GPIO_Port GPIOC
#define Z_RotaryEncoder_A_EXTI_IRQn EXTI3_IRQn
#define X_Enable_Pin GPIO_PIN_1
#define X_Enable_GPIO_Port GPIOA
#define X_Direction_Pin GPIO_PIN_4
#define X_Direction_GPIO_Port GPIOA
#define Z_Direction_Pin GPIO_PIN_6
#define Z_Direction_GPIO_Port GPIOA
#define Z_RotaryEncoder_B_Pin GPIO_PIN_4
#define Z_RotaryEncoder_B_GPIO_Port GPIOC
#define Z_RotaryEncoder_B_EXTI_IRQn EXTI4_IRQn
#define Z_Switch_Pin GPIO_PIN_5
#define Z_Switch_GPIO_Port GPIOC
#define Z_Switch_EXTI_IRQn EXTI9_5_IRQn
#define Red_LED_Pin GPIO_PIN_0
#define Red_LED_GPIO_Port GPIOB
#define SD_Clock_Selecto_Pin GPIO_PIN_1
#define SD_Clock_Selecto_GPIO_Port GPIOB
#define X_Switch_Pin GPIO_PIN_2
#define X_Switch_GPIO_Port GPIOB
#define X_Switch_EXTI_IRQn EXTI2_IRQn
#define X_Moment_Front_Pin GPIO_PIN_6
#define X_Moment_Front_GPIO_Port GPIOC
#define X_Moment_Front_EXTI_IRQn EXTI9_5_IRQn
#define X_Moment_Back_Pin GPIO_PIN_7
#define X_Moment_Back_GPIO_Port GPIOC
#define X_Moment_Back_EXTI_IRQn EXTI9_5_IRQn
#define Z_Moment_Down_Pin GPIO_PIN_9
#define Z_Moment_Down_GPIO_Port GPIOC
#define Z_Moment_Down_EXTI_IRQn EXTI9_5_IRQn
#define Z_Enable_Pin GPIO_PIN_8
#define Z_Enable_GPIO_Port GPIOA
#define Z_Moment_Up_Pin GPIO_PIN_12
#define Z_Moment_Up_GPIO_Port GPIOA
#define Z_Moment_Up_EXTI_IRQn EXTI15_10_IRQn
#define Mode_Manual_Pin GPIO_PIN_10
#define Mode_Manual_GPIO_Port GPIOC
#define Mode_Manual_EXTI_IRQn EXTI15_10_IRQn
#define Start_A_Pin GPIO_PIN_11
#define Start_A_GPIO_Port GPIOC
#define Start_A_EXTI_IRQn EXTI15_10_IRQn
#define Start_B_Pin GPIO_PIN_12
#define Start_B_GPIO_Port GPIOC
#define Yellow_LED_Pin GPIO_PIN_3
#define Yellow_LED_GPIO_Port GPIOB
#define Green_LED_Pin GPIO_PIN_4
#define Green_LED_GPIO_Port GPIOB
#define Blue_LED_Pin GPIO_PIN_5
#define Blue_LED_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
