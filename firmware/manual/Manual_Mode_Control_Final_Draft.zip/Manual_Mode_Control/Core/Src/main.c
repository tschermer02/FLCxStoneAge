/* USER CODE BEGIN Header */
/* Manual Mode Control
 * This program controls the motors via inputs that any trained operator can use
 * This program also controls the LCD screen that displays the information
 *
 * Required files:
 *	liquidcrystal_i2c.h in Core/Inc
 *	liquidcrystal_i2c.c in Core/Src
 *
 *	ftoa.h in Core/Inc
 *	ftoa.c in Core/Src
 *
 * Last Updated: April 26, 2025
 * by David Vasso
 * Written for a STM32F411RET6 Micro-controller
 *
 * More Info:
 * Motors are controlled via step frequency
 * LCD is controlled by I2C, and SD card by SPI
 * Motor signals pass through an Optocoupler from 3.3V to 24V
 *
 * If motor settings are changed via ClearPath or the system is not measuring correctly,
 *  head to the Tuning parameter section and follow the manual instructions
 *
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ftoa.h" //for ftoa function for LCD info
#include "liquidcrystal_i2c.h" //I2C Functions for LCD
#include <stdbool.h> //for bool variable type
#include <stdio.h> //for file manipulation
#include <math.h> //for ceil() and floor()
#include <string.h> //for manipulating LCD outputs
#include <stdarg.h> //For SD card
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
//Velocity States that the motors can be in
typedef enum {
    VEL_RAMP_UP,
    VEL_CONSTANT,
    VEL_RAMP_DOWN,
    VEL_STOPPED
} Vel_State;

//Custom Characters
typedef enum {
    Back,
    Up,
    Down,
    Sus
} Custom_Char;

//Motor Variables and configurations
typedef struct {
	volatile float Slope; //slope of the linear regression
	volatile float Intercept; //y-intercept of the linear regression
	volatile float Vel_Step; //How much the velocity will change when rotating the rotary encoder
	float Max_Vel; //Maximum velocity that the motor can move at

	volatile bool Run; //0 for not moving, 1 for moving
	volatile bool Dir; //Direction
	volatile bool En; //0 for not enabled (no resistance to moving), 1 for enabled

	volatile double Vel_Set; //Set frequency by the operator
	volatile double Freq_Cur; //Current frequency the motor is running at
	volatile uint16_t Top; //Used to change frequency
	volatile uint16_t PS; //Pre-scaler. Used to change frequency
	volatile float Vel_Increment; //How much the motor's velocity will change

	volatile Vel_State State; //Velocity state of motor
	volatile float Pos; //Position of motor
	volatile float UI; //Position buffer variable for integration
	volatile float Vel; //velocity of the motor
} Motor;

//LCD Structure
typedef struct {
	volatile float X_Pos; //X position
	volatile float X_Vel; //X velocity
	volatile float Z_Pos; //Z position
	volatile float Z_Vel; //Z velocity

	volatile uint16_t Type; //Tells which motor is being worked on (1 = X, 2 = Z). 0 is info
	volatile uint16_t Scene; //Tells which scene should be displaying
	volatile uint16_t Row; //Tells which row the cursor is on
	volatile uint16_t Row_Lower_Limit; //Limits where the cursor can go
	volatile uint16_t Row_Upper_Limit;

	volatile float Num; //Used when setting numbers
	volatile uint16_t Num_Digit; //Value of digit being changed
	volatile uint16_t Num_Pos; //Position of digit being changed
	volatile uint16_t Num_Pos_LCD;
} Screen_Data;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//Tuning Parameters Here
#define X_Slope 10000
#define X_Intercept 20

#define Z_Slope 10000
#define Z_Intercept 20

#define Default_X_Step 0.25
#define Default_Z_Step 0.25

#define X_Max_Vel 12.84
#define Z_Max_Vel 6.42

//General System Configurations Here
#define F_Clock 100000000 //Clock of micro-controller (100 MHz)
#define T_Start 250 //Time in milliseconds to go from stop to full speed
#define T_Stop 250 //Time in milliseconds to go from full speed to stop

#define Vel_Tolerance 1 //how close in in/s can the velocity be before snapping to set velocity

#define Blink_Period 650/10 //650 ms to blink a string on the LCD
#define Integral_Period 200/10 //200 ms intervals to update the position

//GPIO Port and Pin labels and purpose here
//Motor Inputs and Outputs
#define X_En_Port GPIOA //X motor enable
const int X_En_Pin = GPIO_PIN_1;

#define X_Dir_Port GPIOA //X motor direction
const int X_Dir_Pin = GPIO_PIN_4;

#define Z_En_Port GPIOA //Z motor enable
const int Z_En_Pin = GPIO_PIN_8;

#define Z_Dir_Port GPIOA //Z motor direction
const int Z_Dir_Pin = GPIO_PIN_6;

//LED Outputs
#define R_LED_Port GPIOB //Indicates if E_Stop is pressed
const int R_LED_Pin = GPIO_PIN_0;

#define Y_LED_Port GPIOB //Indicates if enable is on
const int Y_LED_Pin = GPIO_PIN_3;

#define G_LED_Port GPIOB //Indicates X motor movement
const int G_LED_Pin = GPIO_PIN_4;

#define B_LED_Port GPIOB //Indicates Z motor movement
const int B_LED_Pin = GPIO_PIN_5;

//SD Card
#define SD_CS_Port GPIOB //SD card clock select
const int SD_CS_Pin = GPIO_PIN_1;

//Inputs
#define X_RE_A_Port GPIOC //X rotary encoder A signal
const int X_RE_A_Pin = GPIO_PIN_0;

#define X_RE_B_Port GPIOC //X rotary encoder B signal
const int X_RE_B_Pin = GPIO_PIN_1;

#define X_SW_Port GPIOB //X switch signal
const int X_SW_Pin = GPIO_PIN_2;

#define Z_RE_A_Port GPIOC //Z rotary encoder A signal
const int Z_RE_A_Pin = GPIO_PIN_3;

#define Z_RE_B_Port GPIOC //Z rotary encoder B signal
const int Z_RE_B_Pin = GPIO_PIN_4;

#define Z_SW_Port GPIOC //Z switch signal
const int Z_SW_Pin = GPIO_PIN_5;

#define X_Front_Port GPIOC //X motor Forward Signal
const int X_Front_Pin = GPIO_PIN_6;

#define X_Back_Port GPIOC //X motor Backward Signal
const int X_Back_Pin = GPIO_PIN_7;

#define Z_Up_Port GPIOA //Z motor upward signal
const int Z_Up_Pin = GPIO_PIN_12;

#define Z_Down_Port GPIOC //Z motor downward signal
const int Z_Down_Pin = GPIO_PIN_9;

#define Mode_Port GPIOC //Manual mode signal
const int Mode_Pin = GPIO_PIN_10;

#define St_A_Port GPIOC //Enable starter A signal
const int St_A_Pin = GPIO_PIN_11;

#define St_B_Port GPIOC //Enable starter B signal
const int St_B_Pin = GPIO_PIN_12;

#define E_Stop_Port GPIOC //Emergency stop signal
const int E_Stop_Pin = GPIO_PIN_13;

//Timers
#define X_PWM_Timer htim2 //Timer that make the PWM signal for the X motor
#define Z_PWM_Timer htim3 //Timer that make the PWM signal for the Z motor
#define X_Vel_Timer htim9 //Interrupt changes the velocity for smooth stop
#define Z_Vel_Timer htim10
#define LCD_Timer htim11 //Used to update position
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
//Pressing this symbol will revert to the previous screen
uint8_t Back_Symbol[] = {
  0x04,
  0x0C,
  0x1E,
  0x0D,
  0x05,
  0x01,
  0x02,
  0x0C
};
//Scrolling up will show a new screen. Currently not being used
uint8_t Up_Arrow[] = {
  0x04,
  0x0E,
  0x1F,
  0x04,
  0x04,
  0x04,
  0x04,
  0x00
};
//Scrolling down will show a new screen. Currently not being used
uint8_t Down_Arrow[] = {
  0x00,
  0x04,
  0x04,
  0x04,
  0x04,
  0x1F,
  0x0E,
  0x04
};
//SUS
uint8_t Sus_Symbol[] = {
  0x00,
  0x0E,
  0x18,
  0x18,
  0x1E,
  0x0E,
  0x0A,
  0x0A
};
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim9;
TIM_HandleTypeDef htim10;
TIM_HandleTypeDef htim11;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
//Global variables that interact with interrupts here
Motor X_Motor = {
	.Slope = X_Slope,
	.Intercept = X_Intercept,
	.Vel_Step = Default_X_Step,
	.Max_Vel = X_Max_Vel,

	.Run = 0,
	.Dir = 0,
	.En = 0,

	.Vel_Set = 0,
	.Freq_Cur = 0,
	.Top = 0,
	.PS = 80-1,
	.Vel_Increment = 0,

	.State = VEL_STOPPED,
	.Pos = 0,
	.UI = 0,
	.Vel = 0
};

Motor Z_Motor = {
	.Slope = Z_Slope,
	.Intercept = Z_Intercept,
	.Vel_Step = Default_Z_Step,
	.Max_Vel = Z_Max_Vel,

	.Run = 0,
	.Dir = 0,
	.En = 0,

	.Vel_Set = 0,
	.Freq_Cur = 0,
	.Top = 0,
	.PS = 80-1,
	.Vel_Increment = 0,

	.State = VEL_STOPPED,
	.Pos = 0,
	.UI = 0,
	.Vel = 0
};

Screen_Data LCD = {
	.X_Pos = 0,
	.X_Vel = 0,
	.Z_Pos = 0,
	.Z_Vel = 0,

	.Type = 0,
	.Scene = 0,
	.Row = 0,
	.Row_Lower_Limit = 0,
	.Row_Upper_Limit = 0,

	.Num = 0,
	.Num_Digit = 0,
	.Num_Pos = 0,
	.Num_Pos_LCD = 0
};

//LCD variables
char Num_Buff[12]; //Buffer variable to sending numbers to LCD
char Selected_String[16]; //Buffer variable to send a specific string to LCD
char Selected_String_Size; //Length of selected string
char Line_Clear[] = "          "; //Used to clear a portion of a line
bool Back_Selected = 0; //whether or not the back symbol is selected
bool Blink = 0; //whether to clear selected string or replace it
bool Blinking = 1; //Used to tell whether the row should be blinking

//Motor variables
bool Mode = 0; //0 for manual, 1 for automatic
bool X_Zero = 1; //1 for position at zero on axis
bool Z_Zero = 1;

//Input variables
bool E_Stop = 0;

//Used to keep track of rotary encoder positions
bool X_RE_A = 0;
bool X_RE_B = 0;
bool X_RE_A_Prev = 0;
bool X_RE_B_Prev = 0;

bool Z_RE_A = 0;
bool Z_RE_B = 0;
bool Z_RE_A_Prev = 0;
bool Z_RE_B_Prev = 0;

char Z_RE_State = 0;
char Z_RE_State_Prev = 0;

bool X_CW = 0;
bool Z_CW = 0;

//Flags
//Motor flags
bool X_At_Set_F = 1;
bool Z_At_Set_F = 1;

//LCD flags
bool Info_F = 0; //Used to update info screen
bool Screen_F = 0; //Used to update screen from scene change
bool Row_F = 0; //Used to update row and selected string
bool Blink_F = 0; //Used to update blink
bool Num_Set_F = 0; //Used to change which column is being changed
bool Setting_F = 0; //Used to change a setting

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM11_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM9_Init(void);
static void MX_TIM10_Init(void);
/* USER CODE BEGIN PFP */
void Motor_Change_Speed(Motor* axis);
void Rotary_Encoder(Motor* axis);
void Info_Scene_LCD(void);
void Info_Change_LCD(void);
void Settings_LCD(void);
void Vel_Set_LCD(void);
void Vel_Step_LCD(void);
void E_Stop_LCD(void);
void Auto_Mode_LCD();
void Max_Vel_Error_LCD(void);
void Scene_Change_L_LCD(bool Change);
void Settings_Change_L_LCD(void);
void Num_Set_L_LCD(void);
void Row_Change_L_LCD(void);
void Blink_L_LCD(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
//Used to change motor speed dynamically
void Motor_Change_Speed(Motor* axis) {
	if (axis == &X_Motor) {
		axis -> Freq_Cur = X_Motor.Slope*X_Motor.Vel + X_Motor.Intercept;
		axis -> PS = ceil(F_Clock/(X_Motor.Freq_Cur * 65536));
		axis -> Top = floor((F_Clock/(X_Motor.Freq_Cur * X_Motor.PS)) - 1);

		TIM2 -> PSC = X_Motor.PS;
		TIM2 -> ARR = X_Motor.Top;
		TIM2 -> CCR1 = X_Motor.Top/2;

	} else {
		axis -> Freq_Cur = Z_Motor.Slope*Z_Motor.Vel + Z_Motor.Intercept;
		axis -> PS = ceil(F_Clock/(Z_Motor.Freq_Cur * 65536));
		axis -> Top = floor((F_Clock/(Z_Motor.Freq_Cur * Z_Motor.PS)) - 1);

		TIM3 -> PSC = Z_Motor.PS;
		TIM3 -> ARR = Z_Motor.Top;
		TIM3 -> CCR2 = Z_Motor.Top/2;
	}

}

//Used to decipher which way the rotary encoders are turning
void Rotary_Encoder(Motor* axis) {
	if (axis == &X_Motor) {
		X_RE_A = HAL_GPIO_ReadPin(X_RE_A_Port,X_RE_A_Pin);
		X_RE_B = HAL_GPIO_ReadPin(X_RE_B_Port,X_RE_B_Pin);

		if (X_RE_A != X_RE_A_Prev) {
			if ((X_RE_A == 1 && X_RE_B == 0) || (X_RE_A == 0 && X_RE_B == 1)) {
				X_CW = 1;
			}
			if ((X_RE_A == 0 && X_RE_B == 0) || (X_RE_A == 1 && X_RE_B == 1)) {
				X_CW = 0;
			}
			X_RE_A_Prev = X_RE_A;
		} else if (X_RE_B != X_RE_B_Prev) {
			if ((X_RE_A == 1 && X_RE_B == 0) || (X_RE_A == 0 && X_RE_B == 1)) {
				X_CW = 0;
			}
			if ((X_RE_A == 0 && X_RE_B == 0) || (X_RE_A == 1 && X_RE_B == 1)) {
				X_CW = 1;
			}
			X_RE_B_Prev = X_RE_B;
		}
	} else {
		Z_RE_A = HAL_GPIO_ReadPin(Z_RE_A_Port,Z_RE_A_Pin);
		Z_RE_B = HAL_GPIO_ReadPin(Z_RE_B_Port,Z_RE_B_Pin);

		if (Z_RE_A != Z_RE_A_Prev) {
			if ((Z_RE_A == 1 && Z_RE_B == 0) || (Z_RE_A == 0 && Z_RE_B == 1)) {
				Z_CW = 1;
			}
			if ((Z_RE_A == 0 && Z_RE_B == 0) || (Z_RE_A == 1 && Z_RE_B == 1)) {
				Z_CW = 0;
			}
			Z_RE_A_Prev = Z_RE_A;
		} else if (Z_RE_B != Z_RE_B_Prev) {
			if ((Z_RE_A == 1 && Z_RE_B == 0) || (Z_RE_A == 0 && Z_RE_B == 1)) {
				Z_CW = 0;
			}
			if ((Z_RE_A == 0 && Z_RE_B == 0) || (Z_RE_A == 1 && Z_RE_B == 1)) {
				Z_CW = 1;
			}
			Z_RE_B_Prev = Z_RE_B;
		}
	}

}

//Any function with _LCD is used to update the screen. Any function with _L_LCD deals with LCD logic
void Info_Scene_LCD(void) {
	HD44780_Clear();
	HD44780_SetCursor(0,0);
	HD44780_PrintStr("XPos: ");
	HD44780_SetCursor(18,0);
	HD44780_PrintStr("in");
	HD44780_SetCursor(0,1);
	HD44780_PrintStr("XVel: ");
	HD44780_SetCursor(16,1);
	HD44780_PrintStr("in/s");
	HD44780_SetCursor(0,2);
	HD44780_PrintStr("ZPos: ");
	HD44780_SetCursor(18,2);
	HD44780_PrintStr("in");
	HD44780_SetCursor(0,3);
	HD44780_PrintStr("ZVel: ");
	HD44780_SetCursor(16,3);
	HD44780_PrintStr("in/s");
	Blinking = 0;
	Back_Selected = 0;
	LCD.Row = 0;
	LCD.Row_Lower_Limit = 0;
	LCD.Row_Upper_Limit = 0;
}

void Info_Change_LCD(void) {
	HD44780_SetCursor(6,0);
	HD44780_PrintStr(Line_Clear);
	HD44780_SetCursor(6,0);
	ftoa(LCD.X_Pos,Num_Buff,4);
	HD44780_PrintStr(Num_Buff);
	if (LCD.X_Pos < -100) {
		HD44780_SetCursor(15,0);
	} else {
		HD44780_SetCursor(14,0);
	}
	HD44780_PrintStr("  ");

	HD44780_SetCursor(6,1);
	HD44780_PrintStr(Line_Clear);
	HD44780_SetCursor(6,1);
	ftoa(LCD.X_Vel,Num_Buff,4);
	HD44780_PrintStr(Num_Buff);
	HD44780_SetCursor(14,1);
	HD44780_PrintStr("  ");

	HD44780_SetCursor(6,2);
	HD44780_PrintStr(Line_Clear);
	HD44780_SetCursor(6,2);
	ftoa(LCD.Z_Pos,Num_Buff,4);
	HD44780_PrintStr(Num_Buff);
	if (LCD.Z_Pos < -100) {
		HD44780_SetCursor(15,2);
	} else {
		HD44780_SetCursor(14,2);
	}
	HD44780_PrintStr("  ");

	HD44780_SetCursor(6,3);
	HD44780_PrintStr(Line_Clear);
	HD44780_SetCursor(6,3);
	ftoa(LCD.Z_Vel,Num_Buff,4);
	HD44780_PrintStr(Num_Buff);
	HD44780_SetCursor(14,3);
	HD44780_PrintStr("  ");
}

void Settings_LCD(void) {
	if (LCD.Type == 0) {return;}
	HD44780_Clear();
	HD44780_SetCursor(0,0);
	HD44780_PrintSpecialChar(Back);
	if (LCD.Type == 1) {
		HD44780_PrintStr(" X Axis Settings");
	} else {
		HD44780_PrintStr(" Z Axis Settings");
	}
	HD44780_SetCursor(0,1);
	HD44780_PrintStr("Velocity Set");
	HD44780_SetCursor(0,2);
	HD44780_PrintStr("Velocity Step");
	HD44780_SetCursor(0,3);
	if (LCD.Type == 1) {
		if (X_Zero == 1) {
			HD44780_PrintStr("X Axis Zeroed");
		} else {
			HD44780_PrintStr("Zero X");
		}

	} else {
		if (Z_Zero == 1) {
			HD44780_PrintStr("Z Axis Zeroed");
		} else {
			HD44780_PrintStr("Zero Z");
		}
	}

	LCD.Row_Lower_Limit = 0;
	LCD.Row_Upper_Limit = 3;
}

void Vel_Set_LCD(void) {
	if (LCD.Type == 0) {return;}
	HD44780_Clear();
	HD44780_SetCursor(0,0);
	HD44780_PrintSpecialChar(Back);
	if (LCD.Type == 1) {
		HD44780_PrintStr(" X Velocity Set");
	} else {
		HD44780_PrintStr(" Z Velocity Set");
	}
	HD44780_SetCursor(0,1);
	HD44780_PrintStr("Set: ");
	HD44780_PrintStr("00.0000");
	HD44780_SetCursor(16,1);
	HD44780_PrintStr("in/s");
	HD44780_SetCursor(0,2);
	HD44780_PrintStr("Cur:");
	HD44780_SetCursor(16,2);
	HD44780_PrintStr("in/s");
	HD44780_SetCursor(5,2);
	if (LCD.Type == 1) {
		ftoa(X_Motor.Vel_Set,Num_Buff,4);
		HD44780_PrintStr(Num_Buff);
	} else {
		ftoa(Z_Motor.Vel_Set,Num_Buff,4);
		HD44780_PrintStr(Num_Buff);
	}
	HD44780_SetCursor(14,2);
	HD44780_PrintStr("  ");
	LCD.Row_Lower_Limit = 0;
	LCD.Row_Upper_Limit = 1;
}

void Vel_Step_LCD(void) {
	if (LCD.Type == 0) {return;}
	HD44780_Clear();
	HD44780_SetCursor(0,0);
	HD44780_PrintSpecialChar(Back);
	if (LCD.Type == 1) {
		HD44780_PrintStr(" X Velocity Step");
	} else {
		HD44780_PrintStr(" Z Velocity Step");
	}
	HD44780_SetCursor(0,1);
	HD44780_PrintStr("Set: ");
	HD44780_PrintStr("0.0000");
	HD44780_SetCursor(16,1);
	HD44780_PrintStr("in/s");
	HD44780_SetCursor(0,2);
	HD44780_PrintStr("Cur:");
	HD44780_SetCursor(16,2);
	HD44780_PrintStr("in/s");
	HD44780_SetCursor(5,2);
	if (LCD.Type == 1) {
		ftoa(X_Motor.Vel_Step,Num_Buff,4);
		HD44780_PrintStr(Num_Buff);
	} else {
		ftoa(Z_Motor.Vel_Step,Num_Buff,4);
		HD44780_PrintStr(Num_Buff);
	}
	HD44780_SetCursor(14,2);
	HD44780_PrintStr("  ");
	LCD.Row_Lower_Limit = 0;
	LCD.Row_Upper_Limit = 1;
}

void E_Stop_LCD(void) {
	Blinking = 0;
	Back_Selected = 0;
	LCD.Row = 0;
	LCD.Row_Lower_Limit = 0;
	LCD.Row_Upper_Limit = 0;

	HD44780_Clear();
	HD44780_SetCursor(5,1);
	HD44780_PrintStr("Operations");
	HD44780_SetCursor(6,2);
	HD44780_PrintStr("Stopped!");
}

void Auto_Mode_LCD() {
	Blinking = 0;
	Back_Selected = 0;
	LCD.Row = 0;
	LCD.Row_Lower_Limit = 0;
	LCD.Row_Upper_Limit = 0;

	HD44780_Clear();
	HD44780_SetCursor(5,0);
	HD44780_PrintStr("Automatic");
	HD44780_SetCursor(7,1);
	HD44780_PrintStr("Mode");
	HD44780_SetCursor(6,2);
	HD44780_PrintStr("Enabled");
}

void Max_Vel_Error_LCD(void) {
	HD44780_Clear();
	HD44780_SetCursor(4,0);
	HD44780_PrintStr("Velocity set");
	HD44780_SetCursor(4,1);
	HD44780_PrintStr("over maximum");
	HD44780_SetCursor(3,3);
	HD44780_PrintStr("Max = ");
	if (LCD.Type == 1) {
		ftoa(X_Motor.Max_Vel, Num_Buff,4);
		HD44780_PrintStr(Num_Buff);
	} else {
		ftoa(Z_Motor.Max_Vel,Num_Buff,4);
		HD44780_PrintStr(Num_Buff);
	}
	LCD.Row = 0;
	LCD.Row_Lower_Limit = 0;
	LCD.Row_Upper_Limit = 0;
	Blinking = 0;
}

//Logic for moving between screens
void Scene_Change_L_LCD(bool Change) {
	//Changes Scene based on where position is
	if (Change == 1) {
		switch (LCD.Scene) {
		case 0: //Info -> settings
			LCD.Scene = 1;
			LCD.Row = 0;
			Blinking = 1;
			Back_Selected = 1;
			break;
		case 1:
			switch (LCD.Row) {
			case 0: //Settings -> info
				LCD.Type = 0;
				LCD.Scene = 0;
				LCD.Row = 0;
				Back_Selected = 0;
				break;
			case 1: //Settings -> vel set
				LCD.Scene = 2;
				LCD.Row = 0;
				Back_Selected = 1;
				break;
			case 2: //Settings -> vel step
				LCD.Scene = 3;
				LCD.Row = 0;
				Back_Selected = 1;
				break;
			case 3: //Zero Axis
				Setting_F = 1;
				break;
			}
			break;
		case 2:
			switch (LCD.Row) {
			case 0: //Vel set -> settings
				LCD.Scene = 1;
				LCD.Row = 1;
				Back_Selected = 0;
				break;
			case 1: //Start setting vel sequence
				LCD.Num_Pos++;
				Num_Set_F = 1;
				break;
			}
			break;
		case 3:
			switch (LCD.Row) {
			case 0: //Vel step -> settings
				LCD.Scene = 1;
				LCD.Row = 2;
				Back_Selected = 0;
				break;
			case 1: //Start setting step sequence
				LCD.Num_Pos++;
				Num_Set_F = 1;
				break;
			}
			break;
		case 4: //EStop -> Info
			LCD.Type = 0;
			LCD.Scene = 0;
			LCD.Row = 0;
			break;
		case 5: //Max vel error -> Info
			LCD.Type = 0;
			LCD.Scene = 0;
			LCD.Row = 0;
			break;
		case 6: //Automatic mode -> info
			LCD.Scene = 5;
			LCD.Row = 0;
			break;
		}

	}

	switch (LCD.Scene) {
	case 0:
		Info_Scene_LCD();
		Info_Change_LCD();
		Blinking = 0;
		Back_Selected = 0;
		break;
	case 1:
		Settings_LCD();
		break;
	case 2:
		Vel_Set_LCD();
		break;
	case 3:
		Vel_Step_LCD();
		break;
	case 4:
		E_Stop_LCD();
		break;
	case 5:
		Max_Vel_Error_LCD();
		break;
	case 6:
		Auto_Mode_LCD();
		break;
	}

}

//Logic for implementing a settings change.
void Settings_Change_L_LCD(void) {
	switch (LCD.Scene) {
	case 1:
		if (LCD.Type == 1) {
			LCD.X_Pos = 0;
			X_Motor.Pos = 0;
			X_Zero = 1;
		} else {
			LCD.Z_Pos = 0;
			Z_Motor.Pos = 0;
			Z_Zero = 1;
		}
		break;
	case 2:
		if (LCD.Type == 1) {
			if (LCD.Num > X_Motor.Max_Vel) {
				LCD.Scene = 5;
				Scene_Change_L_LCD(0);
			} else {
				X_Motor.Vel_Set = LCD.Num;
				LCD.X_Vel = LCD.Num;
				Scene_Change_L_LCD(0);
			}

		} else {
				if (LCD.Num > Z_Motor.Max_Vel) {
					LCD.Scene = 5;
					Scene_Change_L_LCD(0);
				} else {
					Z_Motor.Vel_Set = LCD.Num;
					LCD.Z_Vel = LCD.Num;
					Scene_Change_L_LCD(0);
				}
		}
		break;
	case 3:
		if (LCD.Type == 1) {
			X_Motor.Vel_Step = LCD.Num;
			Scene_Change_L_LCD(0);
		} else {
			Z_Motor.Vel_Step = LCD.Num;
			Scene_Change_L_LCD(0);
		}
		break;

	}

}

//Logic for setting a number
void Num_Set_L_LCD(void) {
	if (LCD.Scene == 2) {
		if (LCD.Num_Pos >= 3) {
			LCD.Num_Pos_LCD = 4+LCD.Num_Pos+1;
		} else {
			LCD.Num_Pos_LCD = 4+LCD.Num_Pos;
		}
	}

	if (LCD.Scene == 3) {
		if (LCD.Num_Pos == 2) {
			LCD.Num_Pos = 3;
		}
		LCD.Num_Pos_LCD = 4+LCD.Num_Pos;
	}

	switch (LCD.Num_Pos) {
	case 0:
		return;
		break;
	case 1:
		LCD.Num = 0;
		LCD.Num_Digit = 0;
		break;
	case 2:
		LCD.Num += LCD.Num_Digit*10;
		LCD.Num_Digit = 0;
		break;
	case 3:
		LCD.Num += LCD.Num_Digit*1;
		LCD.Num_Digit = 0;
		break;
	case 4:
		LCD.Num += LCD.Num_Digit*.1;
		LCD.Num_Digit = 0;
		break;
	case 5:
		LCD.Num += LCD.Num_Digit*.01;
		LCD.Num_Digit = 0;
		break;
	case 6:
		LCD.Num += LCD.Num_Digit*.001;
		LCD.Num_Digit = 0;
		break;
	case 7:
		LCD.Num += LCD.Num_Digit*.0001;
		LCD.Num_Digit = 0;
		Setting_F = 1;
		LCD.Num_Pos = 0;
		Scene_Change_L_LCD(0);
		Row_Change_L_LCD();
		break;
	}

}

//Logic for LCD to change row, selected word, and whether or not to blink selected word
void Row_Change_L_LCD(void) {
	//Selected word and size and whether back symbol is selected or not
	switch (LCD.Scene) {
	case 1: //Settings 1 scene
		switch (LCD.Row) {
		case 0:
			Back_Selected = 1;
			break;
		case 1:
			Back_Selected = 0;
			Selected_String_Size = 12;
			strncpy(Selected_String,"Velocity Set", Selected_String_Size+1);
			break;
		case 2:
			Back_Selected = 0;
			Selected_String_Size = 13;
			strncpy(Selected_String,"Velocity Step", Selected_String_Size+1);
			break;
		case 3:
			Back_Selected = 0;
			if (LCD.Type == 1) {
				if (X_Zero == 1) {
					Selected_String_Size = 13;
					strncpy(Selected_String,"X Axis Zeroed", Selected_String_Size+1);
				} else {
					Selected_String_Size = 6;
					strncpy(Selected_String,"Zero X", Selected_String_Size+1);
				}
			} else {
				if (Z_Zero == 1) {
					Selected_String_Size = 13;
					strncpy(Selected_String,"Z Axis Zeroed", Selected_String_Size+1);
				} else {
					Selected_String_Size = 6;
					strncpy(Selected_String,"Zero Z", Selected_String_Size+1);
				}
			}
			break;
		}
		break;
	case 2: //Velocity set scene
		switch (LCD.Row) {
		case 0:
			Back_Selected = 1;
			Selected_String_Size = 12;
			strncpy(Selected_String,"Velocity Set", Selected_String_Size+1);
			break;
		case 1:
			Back_Selected = 0;
			Selected_String_Size = 3;
			strncpy(Selected_String,"Set", Selected_String_Size+1);
			break;
		}
		break;
	case 3: //Velocity step scene
		switch (LCD.Row) {
		case 0:
			Back_Selected = 1;
			Selected_String_Size = 13;
			strncpy(Selected_String,"Velocity Step", Selected_String_Size+1);
			break;
		case 1:
			Back_Selected = 0;
			Selected_String_Size = 3;
			strncpy(Selected_String,"Set", Selected_String_Size+1);
			break;
		}
		break;
	}




}

//Logic for blinking a selected word
void Blink_L_LCD(void) {

	if (LCD.Num_Pos == 0) {
		if (Back_Selected == 0) {
			if (Blink == 0) {
				Blink = 1;
				HD44780_SetCursor(0,LCD.Row);
				int i;
				for (i=0; i<Selected_String_Size;i++)
				{
					HD44780_PrintStr("_");
				}
				} else {
					Blink = 0;
					HD44780_SetCursor(0,LCD.Row);
					HD44780_PrintStr(Selected_String);
				}
		} else {
			if (Blink == 0) {
				Blink = 1;
				HD44780_SetCursor(0,LCD.Row);
				HD44780_PrintStr("_");
			} else {
				Blink = 0;
				HD44780_SetCursor(0,LCD.Row);
				HD44780_PrintSpecialChar(Back);
			}
		}
	} else {
		if (Blink == 0) {
			Blink = 1;
			HD44780_SetCursor(LCD.Num_Pos_LCD,LCD.Row);
			HD44780_PrintStr("_");
		} else {
			Blink = 0;
			HD44780_SetCursor(LCD.Num_Pos_LCD,LCD.Row);
			utoa(LCD.Num_Digit,Num_Buff,10);
			HD44780_PrintStr(Num_Buff);
		}
	}
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM11_Init();
  MX_USART2_UART_Init();
  MX_FATFS_Init();
  MX_TIM9_Init();
  MX_TIM10_Init();
  /* USER CODE BEGIN 2 */
  HD44780_Init(4); //Defining and initializing LCD with 4 rows
  HD44780_CreateSpecialChar(0,Back_Symbol); //Initializing custom symbols
  HD44780_CreateSpecialChar(1,Up_Arrow);
  HD44780_CreateSpecialChar(2,Down_Arrow);
  HD44780_CreateSpecialChar(3,Sus_Symbol);
  HAL_TIM_Base_Start_IT(&LCD_Timer); //Starting Timing function

  HAL_GPIO_WritePin(X_En_Port,X_En_Pin,0); //Makes sure motors aren't enabled
  HAL_GPIO_WritePin(Z_En_Port,Z_En_Pin,0);


  Rotary_Encoder(&X_Motor); //set initial rotary encoder position
  Rotary_Encoder(&Z_Motor);


  Info_Scene_LCD(); //Used to set the initial screen
  Info_Change_LCD();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  //LCD updates here
	  if (E_Stop == 0) {
		  if (Screen_F == 1) {
			  Screen_F = 0;
			  Scene_Change_L_LCD(1);
		  }

		  if (Setting_F == 1) {
			  Setting_F = 0;
			  Settings_Change_L_LCD();
		  }

		  if (Num_Set_F == 1) {
			  Num_Set_F = 0;
			  Num_Set_L_LCD();
		  }

		  if (Row_F == 1) {
			  Row_F = 0;
			  Row_Change_L_LCD();
		  }
		  if (Blink_F == 1) {
			  Blink_F = 0;
			  Blink_L_LCD();
		  }

		  if (LCD.Type == 0 && X_At_Set_F == 1) {
			  LCD.X_Vel = X_Motor.Vel_Set;
		  }

		  if (LCD.Type == 0 && Z_At_Set_F == 1) {
			  LCD.Z_Vel = Z_Motor.Vel_Set;
		  }

		  if (LCD.Type == 0 && Info_F == 1) {
			  Info_F = 0;
			  Info_Change_LCD();
		  }
	  }

	  //LED updates here
	  if ((X_Motor.Vel > 0) && ((HAL_GPIO_ReadPin(X_En_Port,X_En_Pin) == 1) && (Mode == 0)))
	  {
		  HAL_GPIO_WritePin(G_LED_Port,G_LED_Pin,1); //Green LED is on when X motor is running
	  } else {
		  HAL_GPIO_WritePin(G_LED_Port,G_LED_Pin,0);
	  }

	  if ((Z_Motor.Vel > 0) && ((HAL_GPIO_ReadPin(Z_En_Port,Z_En_Pin) == 1) && (Mode == 0)))
	  {
		  HAL_GPIO_WritePin(B_LED_Port,B_LED_Pin,1); //Blue LE is on when Z motor is running
	  } else {
		  HAL_GPIO_WritePin(B_LED_Port,B_LED_Pin,0);
	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 80-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65535;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 80-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM9 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM9_Init(void)
{

  /* USER CODE BEGIN TIM9_Init 0 */

  /* USER CODE END TIM9_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};

  /* USER CODE BEGIN TIM9_Init 1 */

  /* USER CODE END TIM9_Init 1 */
  htim9.Instance = TIM9;
  htim9.Init.Prescaler = 31-1;
  htim9.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim9.Init.Period = 64515;
  htim9.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim9.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim9) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim9, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM9_Init 2 */

  /* USER CODE END TIM9_Init 2 */

}

/**
  * @brief TIM10 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM10_Init(void)
{

  /* USER CODE BEGIN TIM10_Init 0 */

  /* USER CODE END TIM10_Init 0 */

  /* USER CODE BEGIN TIM10_Init 1 */

  /* USER CODE END TIM10_Init 1 */
  htim10.Instance = TIM10;
  htim10.Init.Prescaler = 31-1;
  htim10.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim10.Init.Period = 64515;
  htim10.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim10.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim10) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM10_Init 2 */

  /* USER CODE END TIM10_Init 2 */

}

/**
  * @brief TIM11 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM11_Init(void)
{

  /* USER CODE BEGIN TIM11_Init 0 */

  /* USER CODE END TIM11_Init 0 */

  /* USER CODE BEGIN TIM11_Init 1 */

  /* USER CODE END TIM11_Init 1 */
  htim11.Instance = TIM11;
  htim11.Init.Prescaler = 16-1;
  htim11.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim11.Init.Period = 62499;
  htim11.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim11.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim11) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM11_Init 2 */

  /* USER CODE END TIM11_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, X_Enable_Pin|X_Direction_Pin|Z_Direction_Pin|Z_Enable_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, Red_LED_Pin|SD_Clock_Selecto_Pin|Yellow_LED_Pin|Green_LED_Pin
                          |Blue_LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : Emergency_Stop_Pin X_RotaryEncoder_A_Pin X_RotaryEncoder_B_Pin Z_RotaryEncoder_A_Pin
                           Z_RotaryEncoder_B_Pin X_Moment_Front_Pin X_Moment_Back_Pin Z_Moment_Down_Pin
                           Mode_Manual_Pin */
  GPIO_InitStruct.Pin = Emergency_Stop_Pin|X_RotaryEncoder_A_Pin|X_RotaryEncoder_B_Pin|Z_RotaryEncoder_A_Pin
                          |Z_RotaryEncoder_B_Pin|X_Moment_Front_Pin|X_Moment_Back_Pin|Z_Moment_Down_Pin
                          |Mode_Manual_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : X_Enable_Pin X_Direction_Pin Z_Direction_Pin Z_Enable_Pin */
  GPIO_InitStruct.Pin = X_Enable_Pin|X_Direction_Pin|Z_Direction_Pin|Z_Enable_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Z_Switch_Pin Start_A_Pin */
  GPIO_InitStruct.Pin = Z_Switch_Pin|Start_A_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : Red_LED_Pin SD_Clock_Selecto_Pin Yellow_LED_Pin Green_LED_Pin
                           Blue_LED_Pin */
  GPIO_InitStruct.Pin = Red_LED_Pin|SD_Clock_Selecto_Pin|Yellow_LED_Pin|Green_LED_Pin
                          |Blue_LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : X_Switch_Pin */
  GPIO_InitStruct.Pin = X_Switch_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(X_Switch_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PB15 */
  GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : Z_Moment_Up_Pin */
  GPIO_InitStruct.Pin = Z_Moment_Up_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(Z_Moment_Up_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : Start_B_Pin */
  GPIO_InitStruct.Pin = Start_B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(Start_B_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  HAL_NVIC_SetPriority(EXTI1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);

  HAL_NVIC_SetPriority(EXTI3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
//External Interrupts
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	//X Momentary switch
	if ((Mode == 0) && (((GPIO_Pin == X_Front_Pin) || (GPIO_Pin == X_Back_Pin)) && (E_Stop == 0))) {
		if ((HAL_GPIO_ReadPin(X_Front_Port,X_Front_Pin) == 0)  && (HAL_GPIO_ReadPin(X_Back_Port,X_Back_Pin) == 0)) {
			X_Motor.Vel_Increment = (X_Motor.Vel_Set*20)/(T_Stop); //Calculates Velocity increment for how much the motor needs to change speed
			HAL_TIM_Base_Start_IT(&X_Vel_Timer);
			X_At_Set_F = 0;
		} else {
			HAL_TIM_PWM_Start(&X_PWM_Timer, TIM_CHANNEL_1); //Starting PWM for X
			X_Motor.Run = 1;
			X_Motor.Vel_Increment = (X_Motor.Vel_Set*20)/(T_Start); //Calculates X Stair Height RPM for speeding up
			LCD.X_Pos = X_Motor.Vel_Increment;
			HAL_TIM_Base_Start_IT(&X_Vel_Timer); //Start X timer interrupt
			X_At_Set_F = 0;
		}

		if (HAL_GPIO_ReadPin(X_Front_Port,X_Front_Pin) == 1) {
			X_Motor.Dir = 0;
			HAL_GPIO_WritePin(X_Dir_Port,X_Dir_Pin,0);
		}

		if (HAL_GPIO_ReadPin(X_Back_Port,X_Back_Pin) == 1) {
			X_Motor.Dir = 1;
			HAL_GPIO_WritePin(X_Dir_Port,X_Dir_Pin,1);
		}
	}
	//Z Momentary switch
	if ((Mode == 0) && (((GPIO_Pin == Z_Up_Pin) || (GPIO_Pin == Z_Down_Pin)) && (E_Stop == 0))) {
		if ((HAL_GPIO_ReadPin(Z_Up_Port,Z_Up_Pin) == 0)  && (HAL_GPIO_ReadPin(Z_Down_Port,Z_Down_Pin) == 0)) {
			Z_Motor.Vel_Increment = (Z_Motor.Vel_Set*20)/(T_Stop); //Calculates Velocity increment for how much the motor needs to change speed
			HAL_TIM_Base_Start_IT(&Z_Vel_Timer);
			Z_At_Set_F = 0;
		} else {
			HAL_TIM_PWM_Start(&Z_PWM_Timer, TIM_CHANNEL_2); //Starting PWM for Z
			Z_Motor.Run = 1;
			Z_Motor.Vel_Increment = (Z_Motor.Vel_Set*20)/(T_Start); //Calculates Z Stair Height RPM for speeding up
			HAL_TIM_Base_Start_IT(&Z_Vel_Timer); //Start Z timer interrupt
			Z_At_Set_F = 0;
		}

		if (HAL_GPIO_ReadPin(Z_Up_Port,Z_Up_Pin) == 1) {
			Z_Motor.Dir = 0;
			HAL_GPIO_WritePin(Z_Dir_Port,Z_Dir_Pin,0);
		}

		if (HAL_GPIO_ReadPin(Z_Down_Port,Z_Down_Pin) == 1) {
			Z_Motor.Dir = 1;
			HAL_GPIO_WritePin(Z_Dir_Port,Z_Dir_Pin,1);
		}
	}

	//X pressing rotary encoder
	if (GPIO_Pin == X_SW_Pin && Mode == 0) {
		if (LCD.Num_Pos != 0 && LCD.Type == 1) {
			HD44780_SetCursor(LCD.Num_Pos_LCD,LCD.Row);
			utoa(LCD.Num_Digit,Num_Buff,10);
			HD44780_PrintStr(Num_Buff);
			LCD.Num_Pos++;
			Num_Set_F = 1;
			return;
		}

		switch (LCD.Type) {
		case 0:
			LCD.Type = 1;
			Screen_F = 1;
			break;
		case 1:
			Screen_F = 1;
			break;
		case 2:
			LCD.Type = 1;
			LCD.Scene = 0;
			LCD.Row = 0;
			Back_Selected = 1;
			Screen_F = 1;
			break;
		}
	}

	//Z pressing rotary encoder
	if (GPIO_Pin == Z_SW_Pin && Mode == 0) {
		if (LCD.Num_Pos != 0 && LCD.Type == 2) {
			HD44780_SetCursor(LCD.Num_Pos_LCD,LCD.Row);
			utoa(LCD.Num_Digit,Num_Buff,10);
			HD44780_PrintStr(Num_Buff);
			LCD.Num_Pos++;
			Num_Set_F = 1;
			return;
		}

		switch (LCD.Type) {
		case 0:
			LCD.Type = 2;
			Screen_F = 1;
			break;
		case 1:
			LCD.Type = 2;
			LCD.Scene = 0;
			LCD.Row = 0;
			Back_Selected = 1;
			Screen_F = 1;
			break;
		case 2:
			Screen_F = 1;
			break;
		}
	}

	//Rotating X rotary encoder
	if ((GPIO_Pin == X_RE_A_Pin || GPIO_Pin == X_RE_B_Pin) && Mode == 0) {
		Rotary_Encoder(&X_Motor);
		if (X_CW == 1) {
			if (LCD.Type == 0 && (X_Motor.Vel_Set <= (X_Motor.Max_Vel - X_Motor.Vel_Step))) {
				X_Motor.Vel_Set += X_Motor.Vel_Step;
				Info_F = 1;
			} else  if (LCD.Num_Pos == 0 && (LCD.Row < LCD.Row_Upper_Limit)) {
				if (Blinking == 1 && Back_Selected == 0 && LCD.Num_Pos == 0) {
					HD44780_SetCursor(0,LCD.Row);
					HD44780_PrintStr(Selected_String);
				} else if (Blinking == 1 && Back_Selected == 1) {
					HD44780_SetCursor(0,LCD.Row);
					HD44780_PrintSpecialChar(Back);
				}
				LCD.Row++;
				Row_F = 1;
			} else if (LCD.Num_Pos != 0) {
				LCD.Num_Digit++;
				if (LCD.Num_Digit == 9) {
					LCD.Num_Digit = 0;
				}
			}
		} else {
			if (LCD.Type == 0 && (X_Motor.Vel_Set >= 0 + X_Motor.Vel_Step)) {
				X_Motor.Vel_Set -= X_Motor.Vel_Step;
				Info_F = 1;
			} else if (LCD.Num_Pos == 0 && (LCD.Row > LCD.Row_Lower_Limit)) {
				if (Blinking == 1 && Back_Selected == 0 && LCD.Num_Pos == 0) {
					HD44780_SetCursor(0,LCD.Row);
					HD44780_PrintStr(Selected_String);
				} else if (Blinking == 1 && Back_Selected == 1) {
					HD44780_SetCursor(0,LCD.Row);
					HD44780_PrintSpecialChar(Back);
				}
				LCD.Row--;
				Row_F = 1;
			} else if (LCD.Num_Pos != 0) {
				LCD.Num_Digit--;
				if (LCD.Num_Digit > 10) {
					LCD.Num_Digit = 9;
				}
			}
		}
	}

	//Rotating Z rotary encoder
	if ((GPIO_Pin == Z_RE_A_Pin || GPIO_Pin == Z_RE_B_Pin) && Mode == 0) {
		Rotary_Encoder(&Z_Motor);
		if (Z_CW == 1) {
			if (LCD.Type == 0 && (Z_Motor.Vel_Set <= (Z_Motor.Max_Vel - Z_Motor.Vel_Step))) {
				Z_Motor.Vel_Set += Z_Motor.Vel_Step;
				Info_F = 1;
			} else  if (LCD.Num_Pos == 0 && (LCD.Row < LCD.Row_Upper_Limit)) {
				if (Blinking == 1 && Back_Selected == 0 && LCD.Num_Pos == 0) {
					HD44780_SetCursor(0,LCD.Row);
					HD44780_PrintStr(Selected_String);
				} else if (Blinking == 1 && Back_Selected == 1) {
					HD44780_SetCursor(0,LCD.Row);
					HD44780_PrintSpecialChar(Back);
				}
				LCD.Row++;
				Row_F = 1;
			} else if (LCD.Num_Pos != 0) {
				LCD.Num_Digit++;
				if (LCD.Num_Digit == 9) {
					LCD.Num_Digit = 0;
				}
			}
		} else {
			if (LCD.Type == 0 && (Z_Motor.Vel_Set >= 0 + Z_Motor.Vel_Step)) {
				Z_Motor.Vel_Set -= Z_Motor.Vel_Step;
				Info_F = 1;
			} else if (LCD.Num_Pos == 0 && (LCD.Row > LCD.Row_Lower_Limit)) {
				if (Blinking == 1 && Back_Selected == 0 && LCD.Num_Pos == 0) {
					HD44780_SetCursor(0,LCD.Row);
					HD44780_PrintStr(Selected_String);
				} else if (Blinking == 1 && Back_Selected == 1) {
					HD44780_SetCursor(0,LCD.Row);
					HD44780_PrintSpecialChar(Back);
				}
				LCD.Row--;
				Row_F = 1;
			} else if (LCD.Num_Pos != 0) {
				LCD.Num_Digit--;
				if (LCD.Num_Digit > 10) {
					LCD.Num_Digit = 9;
				}
			}
		}
	}

	//Enable buttons
	if (GPIO_Pin == St_A_Pin && Mode == 0) {
		if (HAL_GPIO_ReadPin(St_B_Port,St_B_Pin) == 1 && (X_Motor.En == 0 || Z_Motor.En == 0)) {
			if ((HAL_GPIO_ReadPin(E_Stop_Port,E_Stop_Pin) == 0) && (E_Stop == 1)) {
				LCD.Type = 0;
				Screen_F = 1;
				E_Stop = 0;
			}
			X_Motor.En = 1;
			Z_Motor.En = 1;
			HAL_GPIO_WritePin(X_En_Port,X_En_Pin,1);
			HAL_GPIO_WritePin(Z_En_Port,Z_En_Pin,1);
			HAL_GPIO_WritePin(Y_LED_Port,Y_LED_Pin,1);
		} else {
			X_Motor.En = 0;
			Z_Motor.En = 0;
			HAL_GPIO_WritePin(X_En_Port,X_En_Pin,0);
			HAL_GPIO_WritePin(Z_En_Port,Z_En_Pin,0);
			HAL_GPIO_WritePin(Y_LED_Port,Y_LED_Pin,0);
		}
	}

	//Emergency stop
	if (GPIO_Pin == E_Stop_Pin) //Pressing E stop
		{
			if (HAL_GPIO_ReadPin(E_Stop_Port,E_Stop_Pin) == 1)
			{
				HAL_GPIO_WritePin(R_LED_Port,R_LED_Pin,1); //Red LED on
				E_Stop = 1;
				HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1); //Stopping PWM for X
				HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1); //Stopping PWM for Z
				X_Motor.Run = 0;
				Z_Motor.Run = 0;
				LCD.Scene = 4; //Scene is set to E_Stop Screen
				E_Stop_LCD();
			} else {
				E_Stop = 0;
				HAL_GPIO_WritePin(R_LED_Port,R_LED_Pin,0);
			}
		}

	//Mode switch
	if (GPIO_Pin == Mode_Pin) //If Mode switch was changed
	{
		if (HAL_GPIO_ReadPin(Mode_Port,Mode_Pin) == 1)
		{
			Mode = 1;
			LCD.Scene = 6;
			Auto_Mode_LCD();
		} else {
			Mode = 0;
			LCD.Type = 0;
			LCD.Scene = 1; //set to settings screen back button which is virtually pressed.
			LCD.Row = 0;
			Back_Selected = 0;
			Blinking = 0;
			Screen_F = 1;
		}
	}
}

//Timer Interrupts
int j; //Blink Rate currently set to a 400 ms period
int k; //Integral LCD change rate currently set to 200 ms
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	if (htim == &LCD_Timer) {
		j++;
		if (j == Blink_Period) {
			j = 0;
			if (Blinking == 1) {
				Blink_F = 1;
			}
		}

		X_Motor.UI = ((X_Motor.Vel*(2*X_Motor.Dir - 1))*X_Motor.En*X_Motor.Run)/100;
		Z_Motor.UI = ((Z_Motor.Vel*(2*Z_Motor.Dir - 1))*Z_Motor.En*Z_Motor.Run)/100;

		k++;
		if (k == Integral_Period) {
			k = 0;

			if (X_Motor.UI != 0)
			{
				Info_F = 1;
				X_Zero = 0;
			}

			if (Z_Motor.UI != 0) {
				Info_F = 1;
				Z_Zero = 0;
			}

		}
		//Updating variables to new position
		X_Motor.Pos += X_Motor.UI;
		Z_Motor.Pos += Z_Motor.UI;
		LCD.X_Pos = X_Motor.Pos;
		LCD.Z_Pos = Z_Motor.Pos;
	}

	//Deals with smooth speed up and down of X motor
	if (htim == &X_Vel_Timer) {
		if ((HAL_GPIO_ReadPin(X_Front_Port,X_Front_Pin) == 0) && (HAL_GPIO_ReadPin(X_Back_Port,X_Back_Pin) == 0) && ((X_Motor.Vel <= (0 + Vel_Tolerance)))) {
			X_Motor.Vel = 0;
			X_Motor.Run = 0;
			X_Motor.State = VEL_STOPPED;
			HAL_TIM_PWM_Stop(&X_PWM_Timer, TIM_CHANNEL_1); //Stopping PWM for X
			HAL_TIM_Base_Stop_IT(&X_Vel_Timer); //Stop X timer interrupt
			X_At_Set_F = 1;
			return; //Makes sure function doesn't run when not to
		}

		if (((HAL_GPIO_ReadPin(X_Front_Port,X_Front_Pin) == 1) || (HAL_GPIO_ReadPin(X_Back_Port,X_Back_Pin) == 1)) && ((X_Motor.Vel <= (X_Motor.Vel_Set + Vel_Tolerance)) && (X_Motor.Vel >= (X_Motor.Vel_Set - Vel_Tolerance)))) {
			X_Motor.Vel = X_Motor.Vel_Set;
			X_Motor.State = VEL_CONSTANT;
			Motor_Change_Speed(&X_Motor);
			HAL_TIM_Base_Stop_IT(&X_Vel_Timer); //Stop X timer interrupt
			X_At_Set_F = 1;
			return;
		}

		if ((HAL_GPIO_ReadPin(X_Front_Port,X_Front_Pin) == 0 && (HAL_GPIO_ReadPin(X_Back_Port,X_Back_Pin) == 0)) && (X_Motor.Vel >= Vel_Tolerance)) {
			X_Motor.Vel -= X_Motor.Vel_Increment;
			LCD.X_Vel = X_Motor.Vel;
			X_Motor.State = VEL_RAMP_DOWN;
			Motor_Change_Speed(&X_Motor);
			Info_F = 1;

		}

		if (((HAL_GPIO_ReadPin(X_Front_Port,X_Front_Pin) == 1) || (HAL_GPIO_ReadPin(X_Back_Port,X_Back_Pin) == 1)) && (X_Motor.Vel <= (X_Motor.Vel_Set - Vel_Tolerance))) {
			X_Motor.Vel += X_Motor.Vel_Increment;
			LCD.X_Vel = X_Motor.Vel;
			X_Motor.State = VEL_RAMP_UP;
			Motor_Change_Speed(&X_Motor);
			Info_F = 1;

		}
	}

	//Deals with smooth speed up and down of Z motor
	if (htim == &Z_Vel_Timer) {
		if ((HAL_GPIO_ReadPin(Z_Up_Port,Z_Up_Pin) == 0) && (HAL_GPIO_ReadPin(Z_Down_Port,Z_Down_Pin) == 0) && ((Z_Motor.Vel <= (0 + Vel_Tolerance)))) {
			Z_Motor.Vel = 0;
			Z_Motor.Run = 0;
			Z_Motor.State = VEL_STOPPED;
			HAL_TIM_PWM_Stop(&Z_PWM_Timer, TIM_CHANNEL_2); //Stopping PWM for X
			HAL_TIM_Base_Stop_IT(&Z_Vel_Timer); //Stop X timer interrupt
			Z_At_Set_F = 1;
			return; //Makes sure function doesn't run when not to
		}

		if (((HAL_GPIO_ReadPin(Z_Up_Port,Z_Up_Pin) == 1) || (HAL_GPIO_ReadPin(Z_Down_Port,Z_Down_Pin) == 1)) && ((Z_Motor.Vel <= (Z_Motor.Vel_Set + Vel_Tolerance)) && (Z_Motor.Vel >= (Z_Motor.Vel_Set - Vel_Tolerance)))) {
			Z_Motor.Vel = Z_Motor.Vel_Set;
			Z_Motor.State = VEL_CONSTANT;
			Motor_Change_Speed(&Z_Motor);
			HAL_TIM_Base_Stop_IT(&Z_Vel_Timer); //Stop X timer interrupt
			Z_At_Set_F = 1;
			return; //Makes sure function doesn't run when not to
		}

		if ((HAL_GPIO_ReadPin(Z_Up_Port,Z_Up_Pin) == 0 && (HAL_GPIO_ReadPin(Z_Down_Port,Z_Down_Pin) == 0)) && (Z_Motor.Vel >= Vel_Tolerance)) {
			Z_Motor.Vel -= Z_Motor.Vel_Increment;
			LCD.Z_Vel = Z_Motor.Vel;
			Z_Motor.State = VEL_RAMP_DOWN;
			Info_F = 1;
			Motor_Change_Speed(&Z_Motor);
		}

		if (((HAL_GPIO_ReadPin(Z_Up_Port,Z_Up_Pin) == 1) || (HAL_GPIO_ReadPin(Z_Down_Port,Z_Down_Pin) == 1)) && (Z_Motor.Vel <= (Z_Motor.Vel_Set - Vel_Tolerance))) {
			Z_Motor.Vel += Z_Motor.Vel_Increment;
			LCD.Z_Vel = Z_Motor.Vel;
			Z_Motor.State = VEL_RAMP_UP;
			Info_F = 1;
			Motor_Change_Speed(&Z_Motor);
		}
	}

}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
